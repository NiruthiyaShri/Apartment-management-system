-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2022 at 12:42 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apartment`
--

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE `cost` (
  `No` int(3) NOT NULL,
  `House_No` text NOT NULL,
  `Month` text NOT NULL,
  `Year` text NOT NULL,
  `Purpose` text DEFAULT NULL,
  `Amount` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`No`, `House_No`, `Month`, `Year`, `Purpose`, `Amount`) VALUES
(1, '11', 'JAN', '2018', 'HHH', '900'),
(2, '12', 'FEB', '2018', 'JJJ', '800'),
(3, '13', 'FEB', '2018', 'GGG', '600'),
(4, '30', 'FEB', '2018', 'RRR', '3000'),
(5, '25', 'JUNE', '2018', 'AABCD', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `houseinfo`
--

CREATE TABLE `houseinfo` (
  `No` int(11) NOT NULL,
  `House_No` text NOT NULL,
  `Floor` text NOT NULL,
  `Unit` text NOT NULL,
  `Details` text NOT NULL,
  `Rent` text NOT NULL,
  `About` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `houseinfo`
--

INSERT INTO `houseinfo` (`No`, `House_No`, `Floor`, `Unit`, `Details`, `Rent`, `About`) VALUES
(1, '10', '1st', 'A', '2 Bed + 1 Drawing + 1 Dinning + 1 Kitchen + 2 Bath', '1000', 'Free'),
(2, '20', '2nd', 'A', '2 Bed + 1 Drawing + 1 Dinning + 1 Kitchen + 2 Bath', '2000', 'Free'),
(3, '30', '3rd', 'A', 'Single Room + Single Bath + Single Kitchen', '3000', 'Sold'),
(4, '25', '3rd', 'B', '2 Bed + 1 Drawing + 1 Dinning + 1 Kitchen + 2 Bath', '15000', 'Booked');

-- --------------------------------------------------------

--
-- Table structure for table `houserent`
--

CREATE TABLE `houserent` (
  `No` int(11) NOT NULL,
  `House_No` text NOT NULL,
  `Floor` text NOT NULL,
  `Unit` text NOT NULL,
  `Tenant_Name` text NOT NULL,
  `Contact` text NOT NULL,
  `Tenant_Id` text NOT NULL,
  `Family_Member` text NOT NULL,
  `Date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `houserent`
--

INSERT INTO `houserent` (`No`, `House_No`, `Floor`, `Unit`, `Tenant_Name`, `Contact`, `Tenant_Id`, `Family_Member`, `Date`) VALUES
(2, '20', '2nd', 'A', 'shri', '987987897', '8799', '3', '3-4-5'),
(3, '30', '1st', 'A', 'farook', '9585068767', '9827', '4', '7-8-7'),
(5, '28', '1st', 'A', 'Latha', '9835462738', '2430', '4', '12-09-2019'),
(6, '21', '3rd', 'A', 'Vetri', '9832532738', '22438', '4', '19-09-2019');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `No` int(11) NOT NULL,
  `House_No` text NOT NULL,
  `Floor` text NOT NULL,
  `Unit` text NOT NULL,
  `Status` text NOT NULL,
  `Date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`No`, `House_No`, `Floor`, `Unit`, `Status`, `Date`) VALUES
(5, '25', '3rd', 'B', 'MOVING IN', '12-05-2021'),
(6, '28', '1st', 'A', 'MOVING IN', '25-05-2019'),
(7, '21', '2nd', 'C', 'MOVING OUT', '25-01-2022');

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `No` int(11) NOT NULL,
  `House_No` text NOT NULL,
  `Floor` text NOT NULL,
  `Unit` text NOT NULL,
  `Rent` text DEFAULT NULL,
  `Electricity_Bill` text DEFAULT NULL,
  `Gas_Bill` text DEFAULT NULL,
  `Water_Bill` text DEFAULT NULL,
  `Other_Charges` text DEFAULT NULL,
  `Total` text NOT NULL,
  `Status` text DEFAULT NULL,
  `Date` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`No`, `House_No`, `Floor`, `Unit`, `Rent`, `Electricity_Bill`, `Gas_Bill`, `Water_Bill`, `Other_Charges`, `Total`, `Status`, `Date`) VALUES
(7, '28', '1st', 'A', '20000', '1000', '1000', '2000', '500', '24500', 'Paid', '18-10-2020'),
(8, '25', '3rd', 'B', '15000', '2000', '1500', '8000', '650', '27150', 'Pending', '18-11-2021'),
(9, '30', '3rd', 'C', '15000', '1000', '1500', '5000', '500', '23000', 'Pending', '08-06-2018');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `No` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Username` text NOT NULL,
  `Sec_Q` text NOT NULL,
  `Answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`No`, `Name`, `Username`, `Sec_Q`, `Answer`) VALUES
(1, 'jey', 'jey', 'What is your mother name?', 'mom'),
(2, 'shri', 'nithu', 'Where do you live in?', 'cdm'),
(4, 'farook', 'far', 'Who is your favourite Person?', 'terror'),
(5, 'Niruthiya Shri', 'Nithuram', 'Who is your favourate teacher?', 'Jancy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cost`
--
ALTER TABLE `cost`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `houseinfo`
--
ALTER TABLE `houseinfo`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `houserent`
--
ALTER TABLE `houserent`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`No`),
  ADD UNIQUE KEY `Username` (`Username`) USING HASH;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cost`
--
ALTER TABLE `cost`
  MODIFY `No` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `houseinfo`
--
ALTER TABLE `houseinfo`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `houserent`
--
ALTER TABLE `houserent`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rent`
--
ALTER TABLE `rent`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
