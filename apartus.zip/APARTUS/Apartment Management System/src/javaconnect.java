
import java.sql.*;
import javax.swing.JOptionPane;
public class javaconnect {
    
public static Connection ConnecrDb(){
    Connection conn=null;
  try{
     Class.forName("com.mysql.jdbc.Driver");
     conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/apartment", "root", "");
     
  } 
  catch(Exception e){
       JOptionPane.showMessageDialog(null,"Not Connected!");
  }
        return conn;
}
    
}
